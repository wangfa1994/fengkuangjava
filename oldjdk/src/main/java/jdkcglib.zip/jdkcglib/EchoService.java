package jdkcglib;

public interface EchoService {

    String echo(String echo);
}
